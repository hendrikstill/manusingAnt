<?php


define('DB_HOST','localhost');
define('DB_NAME','manusing');
define('DB_USER','manusing');
define('DB_PASSWORD','test');

define('DEFAULT_CONTROLLER','Customer');
define('DEFAULT_ACTION','listAll');
define('LOG_LEVEL','info'); //Values ('info','warning','error')
define('LOG_TYPE','display'); //Values ('file','display','database')
define('DESIGN_PATH','./design/index.html');

?>