<?php

/**
 * @author Hendrik
 * @package Lib
 * @abstract
 */
class Plugin
{
	#	internal variables



}
###

?>